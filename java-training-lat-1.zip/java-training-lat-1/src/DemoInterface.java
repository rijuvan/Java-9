public interface DemoInterface {
	int getNumber();

	default String getString() {
		return "Default String";
	}
	
	abstract boolean equals(Object a);
}
