interface IntStack { 
  void push(int item); // store an item 
  int pop(); // retrieve an item 
  default void clear() { 
    System.out.println("clear() not implemented."); 
  }   
}
