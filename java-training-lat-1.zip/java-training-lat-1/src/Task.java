

interface Processable {
	void processInSequence();

	default void processInParallel() {
		System.out.println("Processing in parallel");
	}
	
}

public class Task implements Processable {
	public void processInSequence() {
		System.out.println("Processing in sequence");
	}
	
	public void processInParallel() {
		System.out.println("Processing in parallel********");
	}
	

	public static void main(String args[]) {
		Task t = new Task();
		t.processInSequence();
		t.processInParallel(); // It compiles just fine
	}
}