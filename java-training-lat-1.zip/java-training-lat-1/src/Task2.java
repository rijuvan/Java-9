interface Processable2 {
	void processInSequence();

	default void processInParallel() {
		System.out.println("Default parallel");
	}
}

public class Task2 implements Processable2 {
	public void processInSequence() {
		System.out.println("Processing in sequence");
	}

	/*public void processInParallel() {
		System.out.println("Class parallel");
	}*/
	
public void processInParallel() {
		System.out.println("Default parallel");
	}
	public static void main(String args[]) {
		Task2 t = new Task2();
		t.processInParallel();
		
		
	}
}