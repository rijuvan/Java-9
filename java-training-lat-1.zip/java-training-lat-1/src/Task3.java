interface Processable3 {
	default void processInParallel() {
		System.out.println("Default parallel");
	}
}

class Process3 {
	public void processInParallel() {
		System.out.println("Class parallel");
	}
}

public class Task3 extends Process3 implements Processable3 {
	public static void main(String args[]) {
		Task3 t = new Task3();
		t.processInParallel();
	}
}