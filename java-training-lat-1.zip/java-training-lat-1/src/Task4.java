interface Processable4 {
	void processInSequence();

	default void processInParallel() {
		System.out.println("Processable parallel");
	}
}

interface Parallelizable4 extends Processable4 {
	default void processInParallel() {
		System.out.println("Parallelizable parallel");
	}
}

public class Task4 implements Parallelizable4 {
	public void processInSequence() {
		System.out.println("Processing in sequence");
	}

	public static void main(String args[]) {
		Task4 t = new Task4();
		t.processInParallel();
	}
}
