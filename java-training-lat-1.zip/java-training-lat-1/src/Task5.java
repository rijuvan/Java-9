interface Processable5 {
void processInSequence();
default void processInParallel() {
System.out.println("Processable parallel");
}
}
interface Parallelizable5 {
default void processInParallel() {
System.out.println("Parallelizable parallel");
}
}
public class Task5 implements Processable5, Parallelizable5 {
public void processInSequence() {
System.out.println("Processing in sequence");
}

public  void processInParallel() {
System.out.println("Parallelizable parallel**********");
}
public static void main(String args[]) {
Task t = new Task();
t.processInParallel();
}
}