
@FunctionalInterface
interface ToValidareemial
{
	public boolean vlidateEmail(String s);
	
}



public class TestPre {
	
	public void validEmail(ToValidareemial va,String s)
	{
		
		
	}
	
	public static void main(String args[])
	{
		
		String s1="'ancx";
				String s2="'ancx@";
				String s3="'ancx@.";
				
				
	ToValidareemial emialv=new ToValidareemial() {
		
		@Override
		public boolean vlidateEmail(String s) {
			// TODO Auto-generated method stub
			return s.contains("@.");
		}
	};			
				
				
	}

	
	
	
}
