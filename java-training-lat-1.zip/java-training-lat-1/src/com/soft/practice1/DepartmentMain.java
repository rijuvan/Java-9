package com.soft.practice1;

import java.util.Comparator;
import java.util.function.Predicate;

interface dataFunctional {
	public int lenght(String data);
}

public class DepartmentMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Annonymous class
		Comparator<Department> deptCom = new Comparator<Department>() {

			@Override
			public int compare(Department o1, Department o2) {
				// TODO Auto-generated method stub
				return o1.getDeptName().compareTo(o2.getDeptName());
			}

		};

		// Lambdda Expression

		Comparator<Department> byName = (Department d1, Department d2) -> d1.getDeptName().compareTo(d2.getDeptName());

		dataFunctional data = (String d) -> d.length();

		Predicate<String> predicate = new Predicate<String>() {

			@Override
			public boolean test(String t) {
				// TODO Auto-generated method stub
				return t.endsWith("a");
			}

		};

		System.out.println(predicate.test("Anuj"));

	}

}
