package com.soft.predicate;
import java.util.function.Function;

public class AndThenMain {

  public static void main(String[] args) {
    Function<String,String> converter = (i)-> i.substring(2);
        
    Function<String, String> reverse = (s)-> s.toLowerCase();
   
    System.out.println(converter.apply("amit"));
    
    System.out.println(converter.compose(reverse).apply("AMITK"));
    
    /*System.out.println(converter.apply(3).length());
    System.out.println(converter.andThen(reverse).apply(30).byteValue());*/
  }
}