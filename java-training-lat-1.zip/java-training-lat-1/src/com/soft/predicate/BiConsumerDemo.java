package com.soft.predicate;

import java.util.function.BiConsumer;

public class BiConsumerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BiConsumer<String,String> consumeStr =(t, u) -> System.out.println(t + " " + u);
				consumeStr.accept("Hi","there");
	
				BiConsumer<String, String> first = (t, u)-> System.out.println(t.toUpperCase() + u.toUpperCase());
				BiConsumer<String, String> second = (t, u) -> System.out.println(t.toLowerCase() + u.toLowerCase());
				first.andThen(second).accept("Again", " and again");
	
	}
	
	

}
