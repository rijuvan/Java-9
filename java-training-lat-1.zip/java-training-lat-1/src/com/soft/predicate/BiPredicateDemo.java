package com.soft.predicate;

import java.util.function.BiPredicate;

public class BiPredicateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		BiPredicate< Integer,Integer> div=new BiPredicate<Integer, Integer>() {

			@Override
			public boolean test(Integer t, Integer u) {
				// TODO Auto-generated method stub
				if(t%u!=0)
				return false;
				else
					return true;
			}
		};
		
		
		BiPredicate<Integer, Integer> divisible =(t, u) -> t % u == 0;
				boolean result = divisible.test(10, 5);	
		
	}

}
