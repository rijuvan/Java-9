
package com.soft.predicate ;
import java.util.function.*;

public class ConsumerDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Consumer<Employee> consumer = (t) -> System.out.println(t.getEmployeeName());
		Employee e1 = new Employee(100, "AmitSingh Kumar");

		consumer.accept(e1);

		IntConsumer intconsumer = (t) -> System.out.println(t);

		int[] myArr = { 20, 30, 40, 50, 100 };
		for (int i : myArr) {
			intconsumer.accept(i);
		}

		Function<Integer, String> func = new Function<Integer, String>() {

			@Override
			public String apply(Integer t) {
				// TODO Auto-generated method stub
				return t.toString();
			}
		};

		Function<Integer, String> func2 = t -> t.toString();

		System.out.println(func2.apply(100));

		Function<String, String> f1 = s -> {
			return s.toUpperCase();
		};
		Function<String, String> f2 = s -> {
			return s.toLowerCase();
		};

		System.out.println(f1.compose(f2).apply("Compose"));
		System.out.println(f1.andThen(f2).apply("AndThen"));
		
		
		BiConsumer<String, String> first = (t, u) -> System.out.println(t.toUpperCase() + u.toUpperCase());
		BiConsumer<String, String> second = (t, u) ->System.out.println(t.toLowerCase() + u.toLowerCase());
		first.andThen(second).accept("Again", " and again");
		
		
	}

}
