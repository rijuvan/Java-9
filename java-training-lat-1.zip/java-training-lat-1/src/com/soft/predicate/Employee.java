package com.soft.predicate ;

public class Employee {
	private int empId;
	private String  employeeName;
	public Employee(int empId, String employeeName) {
		super();
		this.empId = empId;
		this.employeeName = employeeName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmployeeName() {
		return employeeName;
	}
	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}
	
	
	
}