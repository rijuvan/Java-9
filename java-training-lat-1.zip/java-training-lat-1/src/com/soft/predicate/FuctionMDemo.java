package com.soft.predicate ;

import java.util.function.BiFunction;
import java.util.function.Function;

public class FuctionMDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Function<Integer, Double>fun=(t) -> t*2.5;
		
		System.out.println(fun.apply(100));
		
BiFunction<Integer,Float, Double> bifun=(t,u)-> t*u*.25;
		

System.out.println(bifun.apply(10,2.5f));


BiFunction<Employee,Integer ,String > biemp=(t,s)-> t.toString();
	

		
	}

}
