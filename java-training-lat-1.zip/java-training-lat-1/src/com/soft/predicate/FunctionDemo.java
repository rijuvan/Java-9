package com.soft.predicate;
import java.util.function.*;

public class FunctionDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function<String, String> f1 = s -> {
			return s.toUpperCase();
			};
			Function<String, String> f2 = s -> {
			return s.toLowerCase();
			};
			
			
			
			System.out.println(f1.compose(f2).apply("Compose"));
			System.out.println(f1.andThen(f2).apply("AndThen"));
	}

}
