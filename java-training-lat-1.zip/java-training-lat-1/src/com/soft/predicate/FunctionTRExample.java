package com.soft.predicate;
import java.util.function.*;
import java.util.*;
class Employee1
{
	private String name;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	private int age;
	public Employee1(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}
	public Employee1() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
public class FunctionTRExample{
  public static void main(String args[]){
    Function<Employee1, String> funcEmpToString= (Employee1 e)-> {return e.getName();};
    List<Employee1> employeeList= 
     Arrays.asList(new Employee1("Tom Jones", 45), 
      new Employee1("Harry Major", 25),
      new Employee1("Ethan Hardy", 65),
      new Employee1("Nancy Smith", 15),
      new Employee1("Deborah Sprightly", 29));
    
    
    List<String> empNameList=convertEmpListToNamesList(employeeList, funcEmpToString);
   
    for(String names:empNameList)
    {
    	System.out.println(names);
    }
 }
 public static List<String> convertEmpListToNamesList(List<Employee1> employeeList, Function<Employee1, String> funcEmpToString){
   List<String> empNameList=new ArrayList<String>(); 
   for(Employee1 emp:employeeList){
     empNameList.add(funcEmpToString.apply(emp));
   }
   return empNameList;
  }
}