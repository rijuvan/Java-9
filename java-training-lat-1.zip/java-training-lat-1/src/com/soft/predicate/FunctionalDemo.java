package com.soft.predicate ;

@FunctionalInterface
interface A {
	boolean equals(Object o);
	int hashCode();
	String toString();
	void method();
	}
public class FunctionalDemo {

}
