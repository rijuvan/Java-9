package com.soft.predicate ;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;



public class LambdaDemoAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Runnable r=()->System.out.println("Hello");
		
	Thread t1=new Thread(r);
	t1.start();
	
	FileFilter filter=(file)-> 
	{
	return file.getName().endsWith(".java");
	};
	
File files[]=new File("D:/").listFiles(filter);



for (File f:files)
{
	System.out.println(f.getName());
}
	
	
List<Employee> empList=new ArrayList<>();

empList.add(new Employee(23,"Anuj"));
empList.add(new Employee(20,"Dev"));
empList.add(new Employee(22,"Dont"));

Comparator<Employee> compLambda=(Employee e1,Employee e2)->{
	return e1.getEmployeeName().compareTo(e2.getEmployeeName());
};

Collections.sort(empList,compLambda);

	
	}

}
