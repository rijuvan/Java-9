package com.soft.predicate ;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.*;

interface SearchNumber
{
boolean findNumbers(List<Integer> list, BiPredicate<Integer, Integer> biPredicate) ;
}

class Numbers {
	public static boolean isMoreThanFifty(int n1, int n2) {
		return (n1 + n2) > 50;
	}
// One way using Bi predicate 
	
	public static List<Integer> findNumbers(List<Integer> l, BiPredicate<Integer, Integer> p) {
		List<Integer> newList = new ArrayList<>();
		for (Integer i : l) {
			if (p.test(i, i + 10)) {
				newList.add(i);
			}
		}
		return newList;
	}
}

public class MethodLikeObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Consumer<String> c = System.out::println;

		/*
		 * EmployeeData d1=new EmployeeData(); d1.setEmpList(new ArrayList());
		 * System.out.println(d1.employeeCount(d1));
		 * 
		 */
	
	}

	

}
