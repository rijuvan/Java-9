package com.soft.predicate ;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.Predicate;

public class PrdeicateExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> empList=new ArrayList<>();

		empList.add(new Employee(23,"Anuj"));
		empList.add(new Employee(20,"Deva"));
		empList.add(new Employee(22,"Donta"));
		
		Predicate<Employee>p1=(t)-> t.getEmployeeName().endsWith("a");
		Predicate<Employee>p2=(t)-> t.getEmpId()>20;
		for(Employee e1:empList)
		{
		if(p2.and(p1).test(e1));
		{
		System.out.println(e1.getEmployeeName() + e1.getEmpId());
		}
		
		
		
		
		}
		
		Predicate<Integer> even = t -> t % 0 == 1;
		boolean result = even.test(5);
		
		
		
		BiPredicate<Integer, Integer> divisible = (t,u) -> t % u ==0;
	

	}

}
