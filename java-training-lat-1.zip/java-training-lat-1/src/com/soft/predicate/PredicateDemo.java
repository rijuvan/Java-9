package com.soft.predicate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.*;
public class PredicateDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<String> startsWithA = t -> t.startsWith("A");
		boolean result = startsWithA.test("AnujSingh");
		System.out.println(result);
		Predicate<String> p2=t -> t.endsWith("a");
		List<String> myNames=Arrays.asList("Amit","Anuj","�bha","rava");
		
		boolean result1 = startsWithA.and(p2).test("Hi");
		
		System.out.println(result1);
		for(String s12:myNames)
		{
			if(p2.test(s12))
				System.out.println(s12);
		}
		
	
		IntPredicate pInt=t-> t%2==0;
		System.out.println(pInt.test(7));
	}

}
