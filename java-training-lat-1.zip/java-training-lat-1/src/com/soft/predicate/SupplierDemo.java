package com.soft.predicate;

import java.util.function.Supplier;

public class SupplierDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String t = "One";
		Supplier<String> supplierStr = new Supplier<String>() {
			@Override
			public String get() {
				return t.toUpperCase();
			}
		};

		System.out.println(supplierStr.get());
		
		// lambda expression
		String t1 = "One";
		Supplier<String> supplierStr1 = () -> t1.toUpperCase();
		System.out.println(supplierStr.get());
		
		
	}

}
