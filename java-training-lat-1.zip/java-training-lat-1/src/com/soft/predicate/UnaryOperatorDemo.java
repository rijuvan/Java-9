package com.soft.predicate;

import java.util.function.DoubleUnaryOperator;
import java.util.function.IntUnaryOperator;
import java.util.function.UnaryOperator;

public class UnaryOperatorDemo {
	int[] a = { 1, 2, 3, 4, 5, 6, 7, 8 };
	double sum = sumNumbers(a, t -> t * 2.5);

	
	
	int sumNumbers(int[] a, DoubleUnaryOperator unary) {
		int sum = 0;
		for (int i : a) {
			sum += unary.applyAsDouble(i)*2.5;
		}
		return sum;
	}
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UnaryOperator<String> uOp = new UnaryOperator<String>() {
			@Override
			public String apply(String t) {
			return t.substring(0,2);
			}
			};
			System.out.println(uOp.apply("Hello"));
		
			UnaryOperator<String> uOp1 = t -> t.substring(0,2);
			System.out.println(uOp1.apply("Hello"));
			
			
			// Int
			
			
			
	}

}
