package stream2;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import static java.util.stream.Collectors.*;

public class CollectDemoA {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = Stream.of(1, 2, 3, 4, 5).collect(() -> new ArrayList<>(), // //
																						// container
				(l, i) -> l.add(i), // Adding an element
				(l1, l2) -> l1.addAll(l2) // Combining elements

		);
		list.forEach(System.out::println);

		// We can make it clearer by adding the argument types:
		/*
		 * List<Integer> list = Stream.of(1, 2, 3, 4, 5) .collect( () -> new
		 * ArrayList<>(), (List<Integer> l, Integer i) -> l.add(i),
		 * (List<Integer> l1, List<Integer> l2) -> l1.addAll(l2) );
		 */

		// Or we can also use method references:
		/*
		 * List<Integer> list = Stream.of(1, 2, 3, 4, 5) .collect(
		 * ArrayList::new, ArrayList::add, ArrayList::addAll );
		 */

		// This way, we can rewrite our previous example:
		List<Integer> list1 = Stream.of(1, 2, 3, 4, 5).collect(ArrayList::new, ArrayList::add, ArrayList::addAll);
		// As:
		List<Integer> list2 = Stream.of(1, 2, 3, 4, 5).collect(Collectors.toList());

		// Joining example
		String s = Stream.of("a", "simple", "string").collect(joining()); // "asimplestring"

		// Collecting to map

		Map<Integer, Integer> map = Stream.of(1, 2, 3, 4, 5, 6).collect(toMap(i -> i % 2, // Key
				i -> i // Value
		));
		
		
		
		// Some more example 
		
		double avg = Stream.of(1, 2, 3).collect(averagingInt(i -> i * 2)); // 4.0
		long count = Stream.of(1, 2, 3).collect(counting()); // 3
		Stream.of(1, 2, 3).collect(maxBy(Comparator.naturalOrder())).ifPresent(System.out::println); // 3
		Integer sum = Stream.of(1, 2, 3).collect(summingInt(i -> i)); // 6
		

	}

}
