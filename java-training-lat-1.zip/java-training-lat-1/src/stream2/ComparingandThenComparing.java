package stream2;

import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparingandThenComparing {

	public static void main(String[] args) {
		List<Employee> employeeList = Arrays.asList(new Employee("Tom", 45), new Employee("Harry", 35),
				new Employee("Harry", 25), new Employee("Ethan", 65), new Employee("Nancy", 15),
				new Employee("Deborah", 29));

	//	Comparator empNameComparator=Comparator.naturalOrder();
		
Comparator<Employee> empNameComparator = Comparator.comparing(Employee::getAge)
				.thenComparing(Employee::getName);
		Collections.sort(employeeList, empNameComparator);
		employeeList.forEach(System.out::println);
		
		
	
	}
	
}
