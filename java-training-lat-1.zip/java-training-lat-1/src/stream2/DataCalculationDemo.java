package stream2;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.IntStream;


public class DataCalculationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = Arrays.asList(57, 38, 37, 54, 2);
		System.out.println(list.stream().count()); // 5
		
		//Second demo
		
		List<String> strings =
				Arrays.asList("Stream","Operations","on","Collections");
				strings.stream()
				.min( Comparator.comparing(
				(String s) -> s.length())
				).ifPresent(System.out::println); //
		
				// Third 
				System.out.println(IntStream.of(28,4,91,30).sum());
				
				// Fourth 
				
				System.out.println(IntStream.of(28,4,91,30).average());
				
				
	}

}
