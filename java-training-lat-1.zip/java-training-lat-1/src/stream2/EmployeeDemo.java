package stream2;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import java.util.function.*;

public class EmployeeDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*List<Employee> empList = new ArrayList<Employee>();
		Employee e1 = new Employee(100, "Alex", 20000);
		Employee e2 = new Employee(101, "Mexo", 22000);
		Employee e3 = new Employee(102, "NeJan", 21000);
		Employee e4 = new Employee(105, "Newton", 40000);
		Employee e5 = new Employee(108, "demoTe", 19000);
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		Stream<Employee> empstream = empList.stream();

		System.out.println(empstream.count());
		*/
		
		
		// other way to create stream 
		
		
		Stream<Double> s = Stream.generate(new Supplier<Double>() {
			public Double get() {
			return Math.random()*5;
			}
			}).limit(5);
		
		s.forEach(t-> System.out.println(t));
		
		
		// creating stream using String builder 
		
		Stream.Builder<String> builder =
				Stream.<String>builder()
				.add("h").add("e").add("l").add("l");
				builder.accept("o");
				Stream<String> s1 = builder.build();
				s1.forEach(System.out::print);
// Using range method of number stream to create a stream 
				
				IntStream s3 = IntStream.range(1, 4); // stream of 1, 2, 3
				s3.forEach(System.out::println);

	}

}
