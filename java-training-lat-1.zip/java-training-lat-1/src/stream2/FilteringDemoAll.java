package stream2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class FilteringDemoAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<String> words = Arrays.asList("sun", "pool", "beach", "kid", "island", "sea", "sand");
		
		
		Stream<String> myS=words.stream();
		words.stream().filter(t -> t.length() <= 3).forEach(System.out::println);

		words.stream().distinct();

	}

}
