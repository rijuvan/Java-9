package stream2;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class FinddataAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*IntStream stream = IntStream.of(1, 2, 3, 4, 5, 6, 7);
		stream.findFirst().ifPresent(System.out::println); // 1
		
		IntStream stream2 = IntStream.of(1, 2, 3, 4, 5, 6, 7);
		stream2.findAny().ifPresent(System.out::println); //
*/		
		
	/*	
		// scodn 
				Stream<String> stream1 = Stream.empty();
				System.out.println(stream1.findAny().isPresent()); // false
				*/
				// Any match 
				
				//IntStream stream3 = IntStream.of(1, 2, 7, 4, 5, 8, 7);
				//System.out.println(stream3.anyMatch(i -> i%3 == 0)); // true
				
// All Match (Stops once operation is ok
				
			IntStream stream4 = IntStream.of(1, 2, 3, 4, -5, 6, 7);
			System.out.println(stream4.allMatch(i -> i > 0)); // true
			
			IntStream stream5 = IntStream.of(1, 2, 3, 4, 5, 6, 7);
			System.out.println(stream5.allMatch(i -> i%3 == 0)); // false
			
			
				
				// Short Circuiting 
				
/*IntStream stream6 = IntStream.of(1, 2, 3, 4, 5, 6, 7);
				boolean b = stream6.filter(i -> {
				System.out.println("Filter:" + i);
				return i % 2 == 0;
				})
				.allMatch(i -> {
				System.out.println("AllMatch:" + i);
				return i < 3;
				});
				System.out.println(b);
				
				
				
		*/
		
		
		
		
	}

}
