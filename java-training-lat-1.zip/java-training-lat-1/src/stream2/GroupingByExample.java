package stream2;

import java.util.List;
import java.util.Map;
import java.util.stream.Stream;
import static java.util.stream.Collectors.*;

public class GroupingByExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Map<Integer, List<Integer>> map = Stream.of(2, 34, 54, 23, 33, 20, 59, 11, 19, 37)
				.collect(groupingBy(i -> i / 10 * 10));

	

	Map<Integer, Long> map1 = Stream.of(2, 34, 54, 23, 33, 20, 59, 11, 19, 37)
			.collect(groupingBy(i -> i / 10 * 10, counting()));

		Map<Integer, Map<String, List<Integer>>> map2 = Stream.of(2, 34, 54, 23, 33, 20, 59, 11, 19, 37)
				.collect(groupingBy(i -> i / 10 * 10, groupingBy(i -> i % 2 == 0 ? "EVEN" : "ODD")));
	
	
		// Partitioning by example 
		
		Map<Boolean, List<Integer>> map4 =
				Stream.of(45, 9, 65, 77, 12, 89, 31)
				.collect(partitioningBy(i -> i < 50));
		
		
	}
}
