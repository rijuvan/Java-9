package stream2;

import java.util.function.Consumer;
import java.util.function.Supplier;
import java.util.stream.Stream;

public class IterationDemoAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Consumer<Object> consumer = new Consumer<Object>() {

			@Override
			public void accept(Object t) {
				// TODO Auto-generated method stub

				System.out.println(t.toString());

			}

		};

		Stream<Double> s = Stream.generate(new Supplier<Double>() {
			public Double get() {
				return Math.random() * 5;
			}
		}).limit(5);

		s.forEach(consumer);

		// chaing the operation

		Stream<String> words = Stream.of("sun", "pool", "beach", "kid", "island", "sea", "sand");
		words.sorted().limit(2).forEach(System.out::println);
		
		

	}

}
