package stream2;

import java.util.stream.Stream;

public class ParallelStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Stream.of("a","b","c","d","e")
		     .forEach(System.out::print);
		
		
		System.out.println();
		Stream.of("a","b","c","d","e")
		.parallel()
		.forEach(System.out::print);
		
		
		
		
		
		
		// Find first any example 
		
		/*long start = System.nanoTime();
		String first = Stream.of("a","b","c","d","e")
		.parallel().findFirst().get();
		long duration = (System.nanoTime() - start) / 1000000;
		System.out.println(
		first + " found in " + duration + " milliseconds");*/

		
		// Find any 
		
		/*long start = System.nanoTime();
		String any = Stream.of("a","b","c","d","e")
		.parallel().findAny().get();
		long duration = (System.nanoTime() - start) / 1000000;
		System.out.println(
		any + " found in " + duration + " milliseconds");
		*/
		
	}

}
