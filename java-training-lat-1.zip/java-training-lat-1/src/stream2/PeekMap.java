package stream2;

import java.util.Arrays;
import java.util.List;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class PeekMap{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// peek Demo

		System.out.format("\n%d", IntStream.of(1, 2, 3, 4, 5, 6).limit(3).peek(i -> System.out.format("%d ", i)).sum());

		// Map Demo ( mapping char to int)

		Stream.of('a', 'b', 'c', 'd', 'e').map(c -> (int) c).forEach(i -> System.out.format("%d ", i));
		// int to double
		IntStream.of(100, 110, 120, 130, 140).mapToDouble(i -> i / 3.0).forEach(i -> System.out.format("%.2f ", i));

		
		//Flat Map 
		
		List<Character> aToD = Arrays.asList('a', 'b', 'c', 'd');
		List<Character> eToG = Arrays.asList('e', 'f', 'g');
		Stream<List<Character>> stream = Stream.of(aToD, eToG);
		
		
		
		
		
		
	}

}
