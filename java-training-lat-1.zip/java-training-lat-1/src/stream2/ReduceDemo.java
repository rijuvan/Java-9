package stream2;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Optional;
import java.util.OptionalInt;
import java.util.stream.IntStream;
import java.util.List;

public class ReduceDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int arr[] = { 1, 2, 3, 4, 5, 6 };
		int sum1 = 0;
		for (int i : arr) {
			sum1 = sum1 + i;

		}

		System.out.println(sum1);

		// Using Reduction method

OptionalInt total = IntStream.of(1, 2, 3, 4, 5, 6).reduce((sum, n) -> sum + n);

		// Second
		List<Integer> myList = Arrays.asList(7, 18, 9, 10, 2);
		// Two ways to obtain the integer product of the elements
		// in myList by use of reduce().
		Optional<Integer> productObj = myList.stream().reduce((a, b) -> a * b);
		if (productObj.isPresent())

	System.out.println("Product as Optional: " + productObj.get());

		int product = myList.stream().reduce(1, (a, b) -> a * b);

		int evenProduct = myList.stream().reduce(1, (a, b) -> {
			if (b % 2 == 0)
				return a * b;
			else
				return a;
		});

		System.out.println("Product as int: " + evenProduct);

	}

}
