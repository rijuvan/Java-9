package stream2;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class StearmSirtingAll {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Integer> list = Arrays.asList(57, 38, 37, 54, 2);
		list.stream().sorted().forEach(System.out::println);
		
		// Second example 
		
		List<String> strings =
				Arrays.asList("Stream","Operations","on","Collections");
				strings.stream()
				.sorted( Comparator.comparing(
				(String s) -> s.length()).reversed()
				)
				.forEach(System.out::println);
		
				
				
		
		
	}

}
