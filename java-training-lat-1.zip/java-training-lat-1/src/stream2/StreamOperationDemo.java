package stream2;

import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamOperationDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Intermediate Operation
		Stream<String> s = Stream.of("m", "k", "c", "t").sorted().limit(3);

		// Terminal Operation
		int[] digits = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 };
		IntStream s2 = IntStream.of(digits);
		long n = s2.count();
		//System.out.println(s2.findFirst()); // An exception is thrown
		
		
		
		// Stream pipeline lazy evaluation 
		Stream.of("sun", "pool", "beach", "kid", "island", "sea", "sand")
		.map(str -> str.length())
		.filter(i -> i > 3)
		.limit(2).forEach(System.out::println);

		// Stream piplne step by Step 
		
		Stream.of("sun", "pool", "beach", "kid", "island", "sea", "sand")
		.map(str -> {
		System.out.println("Mapping: " + str);
		return str.length();
		})
		.filter(i -> {
		System.out.println("Filtering: " + i);
		return i > 3;
		})
		.limit(2)
		.forEach(System.out::println);
		
		
		
		
		
		
		
	}

}
